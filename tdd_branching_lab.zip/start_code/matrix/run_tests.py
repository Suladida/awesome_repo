import unittest
from tests.matrix_test import MatrixTest

if __name__ == "__main__":
    unittest.main()