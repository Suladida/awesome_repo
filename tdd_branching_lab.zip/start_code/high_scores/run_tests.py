import unittest
from tests.high_scores_test import HighScoresTest

if __name__ == "__main__":
    unittest.main()