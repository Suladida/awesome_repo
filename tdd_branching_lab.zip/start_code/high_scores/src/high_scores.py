def latest(scores):
    pass


def personal_best(scores):
    pass


def personal_top_three(scores):
    pass
