def get_result(final_score):
    pass

def get_results(final_scores):
    pass
    # (You could try and use a list comprehension for this)