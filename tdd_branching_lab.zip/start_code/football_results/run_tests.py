import unittest
from tests.football_results_test import FootballResultsTest

if __name__ == "__main__":
    unittest.main()