import unittest
from src.football_results import *

class FootballResultsTest(unittest.TestCase):
    pass
    # Test we get the right result string for a final score dictionary representing -

        # Home win
        # Away win
        # Draw

    # Test we get right list of result strings for a list of final score dictionaries. 


if __name__ == "__main__":
    unittest.main()
