import unittest
from tests.compound_interest_test import CompoundInterestTest


if __name__ == "__main__":
    unittest.main()