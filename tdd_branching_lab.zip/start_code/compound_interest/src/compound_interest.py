class CompoundInterest:
    pass
